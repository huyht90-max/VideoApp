# Movie App Android

Ứng dụng mẫu Kotlin phát các video công khai qua Internet.

## Tạo APK trên GitHub
1. Tạo GitHub repository mới.
2. Upload **nội dung bên trong thư mục MovieApp** vào gốc repository (để `app`, `.github`, `build.gradle.kts` nằm ngay ở gốc).
3. Vào tab Actions > Build Android APK > Run workflow.
4. Chờ build thành công, mở run, tải artifact `MovieApp-debug-apk`.
5. Giải nén artifact, cài `app-debug.apk` trên điện thoại Android.

APK này là debug build để thử nghiệm, không phải bản phát hành đã ký để đăng Play Store.
