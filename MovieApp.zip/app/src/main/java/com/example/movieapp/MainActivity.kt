package com.example.movieapp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var player: VideoView? = null
    private val movies = listOf(
        Pair("Big Buck Bunny • Phim hoạt hình mẫu", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        Pair("Elephant Dream • Phim mẫu", "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
        Pair("For Bigger Joyrides • Video mẫu", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4")
    )
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun base(): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15,18,29)); setPadding(22, 30, 22, 18) }
        setContentView(root)
        return root
    }
    private fun title(text: String, size: Float = 22f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE); setPadding(4, 14, 4, 14)
    }
    private fun showHome() {
        player?.stopPlayback(); player = null
        val layout = base()
        layout.addView(title("🎬 MOVIE APP", 28f))
        layout.addView(title("Chọn video để xem", 17f))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        movies.forEachIndexed { index, movie ->
            val btn = Button(this).apply {
                text = "▶  ${movie.first}"; isAllCaps = false; textSize = 16f
                setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(44,52,75)))
                setPadding(12, 20, 12, 20)
                setOnClickListener { play(movie.first, movie.second) }
            }
            list.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 })
        }
        scroll.addView(list); layout.addView(scroll)
        layout.addView(title("Các video mẫu cần kết nối Internet.", 13f))
    }
    private fun play(name: String, url: String) {
        val layout = base()
        val back = Button(this).apply { text = "← Danh sách phim"; setOnClickListener { showHome() } }
        layout.addView(back)
        layout.addView(title(name, 18f))
        val video = VideoView(this)
        player = video
        layout.addView(video, LinearLayout.LayoutParams(-1, 0, 1f))
        val controls = MediaController(this)
        controls.setAnchorView(video)
        video.setMediaController(controls)
        video.setOnErrorListener { _, _, _ -> Toast.makeText(this, "Không phát được video. Kiểm tra Internet hoặc URL.", Toast.LENGTH_LONG).show(); true }
        video.setOnPreparedListener { video.start(); controls.show(4000) }
        video.setVideoPath(url)
        video.requestFocus()
    }
    override fun onBackPressed() { if (player != null) showHome() else super.onBackPressed() }
    override fun onDestroy() { player?.stopPlayback(); super.onDestroy() }
}
